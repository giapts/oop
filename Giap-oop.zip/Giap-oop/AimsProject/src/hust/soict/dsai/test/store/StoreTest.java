package hust.soict.dsai.test.store;

public class StoreTest {

	private String title;

	

	public void setTitle(String title) {
		this.title = title;
	}
	
}
