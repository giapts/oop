package com.example.demo;

import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.text.*;

public class ParkingHistory {

    public static VBox createParkingHistoryScreen() {
        VBox mainContainer = new VBox(15);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: white;");

        // Header section
        Label headerLabel = new Label("Lịch sử đỗ xe");
        headerLabel.setFont(Font.font("System", FontWeight.BOLD, 18));

        // Current parking info section
        GridPane currentInfo = new GridPane();
        currentInfo.setHgap(10);
        currentInfo.setVgap(5);
        currentInfo.setPadding(new Insets(10));
        currentInfo.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5;");

        addInfoRow(currentInfo, 0, "Học sinh:", "Nguyễn Văn A");
        addInfoRow(currentInfo, 1, "Ngày:", "27/09");
        addInfoRow(currentInfo, 2, "Khu vực:", "C7");
        addInfoRow(currentInfo, 3, "Thời gian vào:", "14:03");
        addInfoRow(currentInfo, 4, "Thời gian ra:", "Chưa");
        addInfoRow(currentInfo, 5, "Loại xe:", "Xe máy");
        addInfoRow(currentInfo, 6, "Thanh toán:", "Hoàn thành");

        // History table
        TableView<ParkingRecord> historyTable = createHistoryTable();
        VBox.setVgrow(historyTable, Priority.ALWAYS);

        mainContainer.getChildren().addAll(headerLabel, currentInfo, historyTable);
        return mainContainer;
    }

    private static void addInfoRow(GridPane grid, int row, String label, String value) {
        Label lblTitle = new Label(label);
        Label lblValue = new Label(value);
        lblTitle.setFont(Font.font("System", FontWeight.BOLD, 12));
        grid.addRow(row, lblTitle, lblValue);
    }

    private static TableView<ParkingRecord> createHistoryTable() {
        TableView<ParkingRecord> table = new TableView<>();

        TableColumn<ParkingRecord, String> vehicleCol = new TableColumn<>("Loại xe");
        TableColumn<ParkingRecord, String> dateCol = new TableColumn<>("Ngày");
        TableColumn<ParkingRecord, String> timeInCol = new TableColumn<>("TG vào");
        TableColumn<ParkingRecord, String> timeOutCol = new TableColumn<>("TG ra");
        TableColumn<ParkingRecord, String> areaCol = new TableColumn<>("Khu vực");
        TableColumn<ParkingRecord, String> statusCol = new TableColumn<>("Thanh toán");

        table.getColumns().addAll(vehicleCol, dateCol, timeInCol, timeOutCol, areaCol, statusCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        return table;
    }

    public static class ParkingRecord {
        private String vehicleType;
        private String date;
        private String timeIn;
        private String timeOut;
        private String area;
        private String status;

        // Constructor and getters/setters here
    }
}
