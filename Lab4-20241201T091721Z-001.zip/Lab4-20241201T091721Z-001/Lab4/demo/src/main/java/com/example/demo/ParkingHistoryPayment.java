package com.example.demo;

import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.text.*;

public class ParkingHistoryPayment {

    public static VBox createParkingHistoryScreen() {
        VBox mainContainer = new VBox(15);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: white;");

        // Header section
        Label headerLabel = new Label("Lịch sử đỗ xe");
        headerLabel.setFont(Font.font("System", FontWeight.BOLD, 18));

        // Current parking info section
        GridPane currentInfo = new GridPane();
        currentInfo.setHgap(10);
        currentInfo.setVgap(5);
        currentInfo.setPadding(new Insets(10));
        currentInfo.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5;");

        addInfoRow(currentInfo, 0, "Học sinh:", "Nguyễn Văn A");
        addInfoRow(currentInfo, 1, "Ngày:", "27/09");
        addInfoRow(currentInfo, 2, "Khu vực:", "C7");
        addInfoRow(currentInfo, 3, "Thời gian vào:", "14:03");
        addInfoRow(currentInfo, 4, "Thời gian ra:", "Chưa");
        addInfoRow(currentInfo, 5, "Loại xe:", "Xe máy");
        addInfoRow(currentInfo, 6, "Thanh toán:", "Hoàn thành");

        // History table
        TableView<ParkingRecord> historyTable = createHistoryTable();
        VBox.setVgrow(historyTable, Priority.ALWAYS);

        mainContainer.getChildren().addAll(headerLabel, currentInfo, historyTable);
        return mainContainer;
    }

    public static VBox createPaymentScreen() {
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: white;");

        // Payment info section
        VBox paymentInfo = new VBox(15);
        paymentInfo.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5; -fx-padding: 15;");

        Label titleLabel = new Label("Kiểm tra xe đang đỗ");
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 16));

        GridPane infoGrid = new GridPane();
        infoGrid.setHgap(10);
        infoGrid.setVgap(8);

        addInfoRow(infoGrid, 0, "Sinh viên:", "Nguyễn Văn A");
        addInfoRow(infoGrid, 1, "MSSV:", "20225748");
        addInfoRow(infoGrid, 2, "Loại xe:", "Xe máy (29L1 99512)");
        addInfoRow(infoGrid, 3, "Khu vực:", "C7");
        addInfoRow(infoGrid, 4, "Vị trí đỗ xe:", "28");
        addInfoRow(infoGrid, 5, "Giá tiền:", "5000 VND");

        // Status section
        Label statusLabel = new Label("Trạng thái: Chưa thanh toán");
        statusLabel.setStyle("-fx-text-fill: red;");

        // Balance section
        VBox balanceBox = new VBox(10);
        balanceBox.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5; -fx-padding: 15;");

        Label balanceLabel = new Label("Kiểm tra số dư trong tài khoản");
        balanceLabel.setFont(Font.font("System", FontWeight.BOLD, 14));

        Label balanceAmount = new Label("Số dư: 145000 VND");

        HBox balanceButtons = new HBox(10);
        Button refreshButton = new Button("Quay lại");
        Button topupButton = new Button("Nạp tiền");
        balanceButtons.getChildren().addAll(refreshButton, topupButton);

        balanceBox.getChildren().addAll(balanceLabel, balanceAmount, balanceButtons);

        // Action buttons
        HBox actionButtons = new HBox(10);
        actionButtons.setAlignment(Pos.CENTER);

        Button backButton = new Button("Quay lại");
        Button payButton = new Button("Thanh toán");
        Button printButton = new Button("In biên lai");

        actionButtons.getChildren().addAll(backButton, payButton, printButton);

        paymentInfo.getChildren().addAll(titleLabel, infoGrid);
        mainContainer.getChildren().addAll(paymentInfo, statusLabel, balanceBox, actionButtons);

        return mainContainer;
    }

    private static void addInfoRow(GridPane grid, int row, String label, String value) {
        Label lblTitle = new Label(label);
        Label lblValue = new Label(value);
        lblTitle.setFont(Font.font("System", FontWeight.BOLD, 12));
        grid.addRow(row, lblTitle, lblValue);
    }

    private static TableView<ParkingRecord> createHistoryTable() {
        TableView<ParkingRecord> table = new TableView<>();

        TableColumn<ParkingRecord, String> vehicleCol = new TableColumn<>("Loại xe");
        TableColumn<ParkingRecord, String> dateCol = new TableColumn<>("Ngày");
        TableColumn<ParkingRecord, String> timeInCol = new TableColumn<>("TG vào");
        TableColumn<ParkingRecord, String> timeOutCol = new TableColumn<>("TG ra");
        TableColumn<ParkingRecord, String> areaCol = new TableColumn<>("Khu vực");
        TableColumn<ParkingRecord, String> statusCol = new TableColumn<>("Thanh toán");

        table.getColumns().addAll(vehicleCol, dateCol, timeInCol, timeOutCol, areaCol, statusCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        return table;
    }

    public static class ParkingRecord {
        private String vehicleType;
        private String date;
        private String timeIn;
        private String timeOut;
        private String area;
        private String status;

        // Constructor and getters/setters here
    }
}