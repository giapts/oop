package com.example.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ParkingSystem extends Application {
    private static Tab parkingLotTab;
    private static Tab dashboardTab;
    private static Tab loginTab;
    private static Tab parkingHistoryTab;
    private static Tab paymentTab;
    private static TabPane tabPane;  // Biến này phải là static

    @Override
    public void start(Stage primaryStage) {
        tabPane = new TabPane();  // Cập nhật lại thành biến static

        // Login Tab
        loginTab = new Tab("Login");
        loginTab.setClosable(false);
        VBox loginBox = createLoginScreen();
        loginTab.setContent(loginBox);

        // Parking Lot Tab
        parkingLotTab = new Tab("Thông tin bãi đỗ xe");
        parkingLotTab.setClosable(false);
        VBox parkingLotLayout = ParkingLotInfo.createParkingLotScreen();
        parkingLotTab.setContent(parkingLotLayout);
        parkingLotTab.setDisable(true); // Disable initially

        // Dashboard Tab
        dashboardTab = new Tab("Dashboard");
        dashboardTab.setClosable(false);
        BorderPane dashboardLayout = StudentDashboard.createDashboard();
        dashboardTab.setContent(dashboardLayout);
        dashboardTab.setDisable(true); // Disable initially

        // Parking History Tab
        parkingHistoryTab = new Tab("Lịch sử đỗ xe");
        parkingHistoryTab.setClosable(false);
        VBox parkingHistoryLayout = ParkingHistory.createParkingHistoryScreen();
        parkingHistoryTab.setContent(parkingHistoryLayout);
        parkingHistoryTab.setDisable(true); // Disable initially

        // Payment Tab
        paymentTab = new Tab("Thanh toán");
        paymentTab.setClosable(false);
        VBox paymentLayout = Payment.createPaymentScreen();
        paymentTab.setContent(paymentLayout);
        paymentTab.setDisable(true); // Disable initially

        // Add tabs to TabPane
        tabPane.getTabs().addAll(loginTab, dashboardTab, parkingLotTab, parkingHistoryTab, paymentTab);

        // Login button action
        Button loginButton = (Button) loginBox.lookup(".button");
        loginButton.setOnAction(event -> {
            // Simple login check
            TextField usernameField = (TextField) loginBox.lookup(".text-field");
            PasswordField passwordField = (PasswordField) loginBox.lookup(".password-field");

            if (!usernameField.getText().isEmpty() && !passwordField.getText().isEmpty()) {
                // Enable the other tabs and switch to Dashboard tab
                parkingLotTab.setDisable(false);
                dashboardTab.setDisable(false);
                parkingHistoryTab.setDisable(false);
                paymentTab.setDisable(false);
                tabPane.getSelectionModel().select(dashboardTab); // Switch to Dashboard tab
            } else {
                // Show error message if login is invalid
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Login Error");
                alert.setHeaderText(null);
                alert.setContentText("Please enter both username and password.");
                alert.showAndWait();
            }
        });

        // Scene setup
        Scene scene = new Scene(tabPane, 800, 600);
        primaryStage.setTitle("Student Parking System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createLoginScreen() {
        VBox loginBox = new VBox(20);
        loginBox.setAlignment(Pos.CENTER);
        loginBox.setPadding(new Insets(50));
        loginBox.setStyle("-fx-background-color: #ff3b30;");

        // Login panel
        VBox loginPanel = new VBox(15);
        loginPanel.setStyle("-fx-background-color: white; -fx-background-radius: 10;");
        loginPanel.setPadding(new Insets(30));
        loginPanel.setMaxWidth(400);

        Label titleLabel = new Label("Student Login");
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 24));

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.setStyle("-fx-background-radius: 5;");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setStyle("-fx-background-radius: 5;");

        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #ff3b30; -fx-text-fill: white; -fx-background-radius: 5;");
        loginButton.setPrefWidth(200);

        Hyperlink forgotPassword = new Hyperlink("Forgot Password?");
        Hyperlink register = new Hyperlink("Register");

        loginPanel.getChildren().addAll(titleLabel, usernameField, passwordField, loginButton, forgotPassword, register);
        loginPanel.setAlignment(Pos.CENTER);

        loginBox.getChildren().add(loginPanel);

        return loginBox;
    }

    // Phương thức đăng xuất
    public static void showLoginScreen() {
        // Đảm bảo rằng các tab khác đều bị vô hiệu hóa
        parkingLotTab.setDisable(true);
        dashboardTab.setDisable(true);
        parkingHistoryTab.setDisable(true);
        paymentTab.setDisable(true);

        // Chọn lại tab login
        tabPane.getSelectionModel().select(loginTab);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
