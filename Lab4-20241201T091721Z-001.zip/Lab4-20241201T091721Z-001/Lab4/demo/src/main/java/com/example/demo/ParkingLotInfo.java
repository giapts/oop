package com.example.demo;

import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.*;

public class ParkingLotInfo {

    public static VBox createParkingLotScreen() {
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: white;");

        // Header
        Label headerLabel = new Label("Thông tin bãi đỗ xe");
        headerLabel.setFont(Font.font("System", FontWeight.BOLD, 18));

        // Parking grid
        GridPane parkingGrid = createParkingGrid();

        // Information panel
        VBox infoPanel = createInfoPanel();

        // Vehicle selection
        VBox vehicleSelection = createVehicleSelection();

        // Button controls
        HBox controls = createControls();

        mainContainer.getChildren().addAll(headerLabel, parkingGrid, infoPanel, vehicleSelection, controls);
        return mainContainer;
    }

    private static GridPane createParkingGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(5);
        grid.setVgap(5);
        grid.setPadding(new Insets(10));

        // Column headers
        for (int i = 1; i <= 3; i++) {
            Label header = new Label(String.format("%02d", i));
            grid.add(header, i-1, 0);
        }

        // Parking spaces
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 7; col++) {
                Rectangle space = new Rectangle(40, 40);
                space.setFill(Color.WHITE);
                space.setStroke(Color.GRAY);
                grid.add(space, col, row + 1);
            }
        }

        return grid;
    }

    private static VBox createInfoPanel() {
        VBox panel = new VBox(10);
        panel.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5; -fx-padding: 10;");

        Label infoTitle = new Label("Thông tin bãi đỗ xe");
        infoTitle.setFont(Font.font("System", FontWeight.BOLD, 14));

        GridPane info = new GridPane();
        info.setHgap(10);
        info.setVgap(5);

        addInfoRow(info, 0, "Sinh viên:", "Nguyễn Văn A");
        addInfoRow(info, 1, "Khu vực:", "C7");
        addInfoRow(info, 2, "Bãi trống:", "20/50");

        panel.getChildren().addAll(infoTitle, info);
        return panel;
    }

    private static VBox createVehicleSelection() {
        VBox selection = new VBox(10);
        selection.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5; -fx-padding: 10;");

        Label title = new Label("Thay đổi loại xe đỗ?");
        title.setFont(Font.font("System", FontWeight.BOLD, 14));

        ToggleGroup vehicleGroup = new ToggleGroup();
        RadioButton carOption = new RadioButton("Ô tô");
        RadioButton bikeOption = new RadioButton("Xe đạp");
        carOption.setToggleGroup(vehicleGroup);
        bikeOption.setToggleGroup(vehicleGroup);

        selection.getChildren().addAll(title, carOption, bikeOption);
        return selection;
    }

    private static HBox createControls() {
        HBox controls = new HBox(10);
        controls.setAlignment(Pos.CENTER);

        Button backButton = new Button("Quay lại");
        Button bookButton = new Button("Đặt chỗ");

        backButton.setStyle("-fx-background-color: #f0f0f0;");
        bookButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        controls.getChildren().addAll(backButton, bookButton);
        return controls;
    }

    private static void addInfoRow(GridPane grid, int row, String label, String value) {
        Label lblTitle = new Label(label);
        Label lblValue = new Label(value);
        lblTitle.setFont(Font.font("System", FontWeight.BOLD, 12));
        grid.addRow(row, lblTitle, lblValue);
    }
}
