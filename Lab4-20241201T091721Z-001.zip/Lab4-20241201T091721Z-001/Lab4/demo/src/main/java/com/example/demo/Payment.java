package com.example.demo;

import javafx.geometry.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;

public class Payment {
    public static VBox createPaymentScreen() {
        VBox mainContainer = new VBox(15);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: white;");

        Label titleLabel = new Label("Thanh toán");
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 20));

        // Current parking details
        VBox parkingDetails = createParkingDetails();

        // Account balance
        VBox accountBalance = createAccountBalance();

        // Payment buttons
        HBox paymentButtons = createPaymentButtons();

        mainContainer.getChildren().addAll(titleLabel, parkingDetails, accountBalance, paymentButtons);
        return mainContainer;
    }

    private static VBox createParkingDetails() {
        VBox details = new VBox(10);
        details.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5; -fx-padding: 15;");

        Label sectionTitle = new Label("Kiểm tra xe đang đỗ");
        sectionTitle.setFont(Font.font("System", FontWeight.BOLD, 14));

        GridPane info = new GridPane();
        info.setHgap(15);
        info.setVgap(10);

        addInfoRow(info, 0, "Sinh viên:", "Nguyễn Văn A");
        addInfoRow(info, 1, "MSSV:", "20225748");
        addInfoRow(info, 2, "Loại xe:", "Xe máy (29L1 99512)");
        addInfoRow(info, 3, "Khu vực:", "C7");
        addInfoRow(info, 4, "Vị trí đỗ xe:", "28");
        addInfoRow(info, 5, "Giá tiền:", "5000 VND");

        Label statusLabel = new Label("Trạng thái: Chưa thanh toán");
        statusLabel.setStyle("-fx-text-fill: red;");

        details.getChildren().addAll(sectionTitle, info, statusLabel);
        return details;
    }

    private static VBox createAccountBalance() {
        VBox balance = new VBox(10);
        balance.setStyle("-fx-border-color: #ddd; -fx-border-radius: 5; -fx-padding: 15;");

        Label sectionTitle = new Label("Kiểm tra số dư trong tài khoản");
        sectionTitle.setFont(Font.font("System", FontWeight.BOLD, 14));

        Label balanceAmount = new Label("Số dư: 145000 VND");
        balanceAmount.setFont(Font.font("System", 14));

        Button updateButton = new Button("Cập nhật số dư mới");
        updateButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");

        balance.getChildren().addAll(sectionTitle, balanceAmount, updateButton);
        return balance;
    }

    private static HBox createPaymentButtons() {
        HBox buttons = new HBox(10);
        buttons.setAlignment(Pos.CENTER);

        Button backButton = new Button("Quay lại");
        Button payButton = new Button("Thanh toán");
        Button printButton = new Button("In biên lai");
        Button saveButton = new Button("In biên lai về điện tử");

        backButton.setStyle("-fx-background-color: #f0f0f0;");
        payButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        printButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");
        saveButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white;");

        buttons.getChildren().addAll(backButton, payButton, printButton, saveButton);
        return buttons;
    }

    private static void addInfoRow(GridPane grid, int row, String label, String value) {
        Label lblTitle = new Label(label);
        Label lblValue = new Label(value);
        lblTitle.setFont(Font.font("System", FontWeight.BOLD, 12));
        grid.addRow(row, lblTitle, lblValue);
    }
}
